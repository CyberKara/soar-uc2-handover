# File: proofpoint_trap_connector.py
import email.policy
import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone
from email.parser import BytesHeaderParser
from urllib.parse import urlparse

import requests
import urllib3
from requests.adapters import HTTPAdapter

import phantom.app as phantom
from phantom.base_connector import BaseConnector
from phantom.action_result import ActionResult
from phantom.vault import Vault

from proofpoint_trap_consts import *


class ProofpointTrapConnector(BaseConnector):

    def __init__(self):
        super(ProofpointTrapConnector, self).__init__()
        self._state = None
        self._session = None
        self._base_url = None
        self._verify = False
        self._timeout = DEFAULT_TIMEOUT

    def initialize(self):
        self._state = self.load_state()
        if not isinstance(self._state, dict):
            self.debug_print("Resetting corrupted state file")
            self._state = {"app_version": self.get_app_json().get("app_version")}

        config = self.get_config()
        self._base_url = config.get(BASE_URL_KEY, "").rstrip("/")
        self._verify = config.get(VERIFY_SSL_KEY, True)
        self._timeout = config.get(TIMEOUT_KEY, DEFAULT_TIMEOUT)
        api_key = config.get(API_KEY_KEY, "")

        if not self._base_url.lower().startswith("https://"):
            self.save_progress(
                "Config Error: base_url must use https:// — plain HTTP would expose "
                "the API key in transit. Received: {!r}".format(self._base_url[:50])
            )
            return phantom.APP_ERROR

        # trust_env stays on (requests' default, as in Splunk's own apps): SOAR
        # passes its proxy settings and certificate store (REQUESTS_CA_BUNDLE)
        # to the action through the environment.
        self._session = requests.Session()
        retry = urllib3.Retry(
            total=MAX_RETRIES,
            backoff_factor=1,
            status_forcelist=RETRYABLE_STATUS_CODES,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        self._session.headers.update({
            "Authorization": api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

        return phantom.APP_SUCCESS

    def finalize(self):
        if self._session:
            self._session.close()
        self.save_state(self._state)
        return phantom.APP_SUCCESS

    def handle_action(self, param):
        action_id = self.get_action_identifier()
        self.debug_print("action_id", action_id)

        action_mapping = {
            "test_connectivity": self._handle_test_connectivity,
            "on_poll": self._handle_on_poll,
            "list_incidents": self._handle_list_incidents,
            "get_incident": self._handle_get_incident,
            "close_incident": self._handle_close_incident,
            "add_comment": self._handle_add_comment,
            "download_mime_body": self._handle_download_mime_body,
            "add_user_to_incident": self._handle_add_user_to_incident,
            "update_incident_description": self._handle_update_incident_description,
            "update_incident_assignee": self._handle_update_incident_assignee,
            "set_incident_field": self._handle_set_incident_field,
        }

        action = action_mapping.get(action_id)
        if action:
            return action(param)

        return phantom.APP_ERROR

    def handle_exception(self, exception):
        self.set_status(
            phantom.APP_ERROR,
            "Unhandled exception: {}".format(
                self._get_error_message_from_exception(exception)
            ),
        )
        return phantom.APP_ERROR

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    def _get_error_message_from_exception(self, e):
        error_code = None
        error_message = "Error message unavailable"
        try:
            if hasattr(e, "args") and e.args:
                if len(e.args) > 1:
                    error_code = e.args[0]
                    error_message = e.args[1]
                elif len(e.args) == 1:
                    error_message = e.args[0]
        except Exception:
            pass
        if not error_code:
            return "Error Message: {}".format(error_message)
        return "Error Code: {}. Error Message: {}".format(error_code, error_message)

    # ------------------------------------------------------------------
    # Input validation helpers
    # ------------------------------------------------------------------

    def _validate_integer(self, action_result, parameter, key, allow_zero=False):
        try:
            if not float(parameter).is_integer():
                raise ValueError()
            parameter = int(parameter)
        except Exception:
            action_result.set_status(
                phantom.APP_ERROR,
                "Invalid integer value for '{}' parameter".format(key),
            )
            return None
        if allow_zero:
            if parameter < 0:
                action_result.set_status(
                    phantom.APP_ERROR,
                    "'{}' must be a non-negative integer".format(key),
                )
                return None
        else:
            if parameter <= 0:
                action_result.set_status(
                    phantom.APP_ERROR,
                    "'{}' must be a positive integer".format(key),
                )
                return None
        return parameter

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _fail(self, action_result, msg):
        """Set error status on action_result or self (when on_poll has no action_result)."""
        if action_result is not None:
            return action_result.set_status(phantom.APP_ERROR, msg)
        return self.set_status(phantom.APP_ERROR, msg)

    def _make_rest_call(self, method, url, action_result=None, **kwargs):
        """Execute an HTTP call and process the response.

        Returns:
            tuple: (status, data) — RetVal pattern. data is the parsed body
            on success, None on failure.
        """
        try:
            response = self._session.request(
                method, url, timeout=self._timeout, verify=self._verify, **kwargs
            )
        except requests.exceptions.SSLError:
            return self._fail(action_result, ERR_SSL), None
        except requests.exceptions.ConnectionError:
            return self._fail(action_result, ERR_CONNECTION.format(self._base_url)), None
        except requests.exceptions.Timeout:
            return self._fail(action_result, ERR_TIMEOUT.format(self._timeout)), None
        except Exception as e:
            return self._fail(
                action_result, "API Error: Unexpected error \u2014 {}".format(str(e))
            ), None

        return self._process_response(response, action_result)

    def _process_response(self, response, action_result=None):
        """Parse an HTTP response with content-type detection.

        Returns:
            tuple: (status, data) — RetVal pattern.
        """
        if action_result is not None:
            action_result.add_debug_data({
                'r_status_code': response.status_code,
                'r_text': response.text,
                'r_headers': dict(response.headers),
            })

        status_code = response.status_code
        content_type = response.headers.get('Content-Type', '')

        if status_code in (401, 403):
            return self._fail(action_result, ERR_AUTH), None

        # 404 is deliberately NOT special-cased as "not found" here -- TRAP
        # also uses it for business-logic signals unrelated to a missing
        # resource (e.g. update team and assignee returns 404 when the
        # requested values already match the incident's current state).
        # Falls through to the same JSON/text/empty handling as every other
        # non-2xx status, which already surfaces the real body's
        # message/error field when present.

        if 'json' in content_type:
            return self._process_json_response(response, action_result)

        if 'html' in content_type:
            return self._fail(
                action_result,
                "Unexpected HTML response (HTTP {}) \u2014 check base_url".format(status_code)
            ), None

        if not response.text:
            if 200 <= status_code < 300:
                return phantom.APP_SUCCESS, {}
            return self._fail(
                action_result, "Empty response (HTTP {})".format(status_code)
            ), None

        if 200 <= status_code < 300:
            return phantom.APP_SUCCESS, response.text

        return self._fail(
            action_result,
            "API Error: HTTP {} \u2014 {}".format(status_code, response.text[:200])
        ), None

    def _process_json_response(self, response, action_result):
        """Parse a JSON response and map HTTP errors to descriptive messages."""
        try:
            data = response.json()
        except ValueError as e:
            return self._fail(
                action_result,
                "Unable to parse JSON response. Error: {}".format(str(e))
            ), None

        status_code = response.status_code
        if 200 <= status_code < 300:
            return phantom.APP_SUCCESS, data

        if isinstance(data, dict):
            msg = data.get("message") or data.get("error") or response.text[:200]
        else:
            msg = response.text[:200]
        return self._fail(
            action_result,
            "API Error: HTTP {} \u2014 {}".format(status_code, msg)
        ), None

    # ------------------------------------------------------------------
    # Disposition helpers
    # ------------------------------------------------------------------

    def _get_disposition(self, incident):
        for field in incident.get("incident_field_values", []):
            if field.get("name") == "Abuse Disposition":
                return field.get("value", "")
        return ""

    def _get_field_value(self, incident, field_name):
        for field in incident.get("incident_field_values", []):
            if field.get("name") == field_name:
                return field.get("value", "")
        return ""

    def _passes_disposition_filter(self, incident, allowed_dispositions):
        if not allowed_dispositions:
            return True
        disposition = self._get_disposition(incident)
        return disposition in allowed_dispositions

    def _passes_sub_disposition_filter(self, incident, allowed_sub_dispositions):
        if not allowed_sub_dispositions:
            return True
        sub_disposition = self._get_field_value(incident, "Sub Disposition")
        return sub_disposition in allowed_sub_dispositions

    def _fetch_and_filter_incidents(self, action_result, state, window_start, window_end,
                                     allowed_dispositions, allowed_sub_dispositions,
                                     expand_events="false", date_field="created"):
        """Fetch incidents in <=30-day chunks (TRAP's date-range cap, see
        MAX_POLL_WINDOW_HOURS) and apply the same client-side Abuse/Sub
        Disposition filtering as on_poll. Shared by on_poll and the
        'list incidents' action so both stay in sync. date_field "closed"
        windows on the close date instead (TRAP takes one family per call);
        state None lists every state.

        Returns:
            tuple: (status, incidents) — RetVal pattern; incidents is a
            disposition-filtered list on success, None on failure.
        """
        url = "{}{}".format(self._base_url, INCIDENTS_PATH)
        incidents_by_id = {}
        chunk_start = window_start
        while chunk_start < window_end:
            chunk_end = min(chunk_start + timedelta(hours=MAX_POLL_WINDOW_HOURS), window_end)
            params = {
                "state": state,
                date_field + "_after": chunk_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
                date_field + "_before": chunk_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "expand_events": expand_events,
            }

            ret_val, chunk_incidents = self._make_rest_call(
                "GET", url, action_result, params=params
            )
            if phantom.is_fail(ret_val):
                # _make_rest_call already set a detailed message on
                # action_result (or self, when action_result is None) — just
                # propagate the failure, don't clobber it with a generic one.
                return ret_val, None

            if isinstance(chunk_incidents, list):
                for inc in chunk_incidents:
                    inc_id = inc.get("id")
                    if inc_id is not None:
                        incidents_by_id[inc_id] = inc

            chunk_start = chunk_end

        incidents = list(incidents_by_id.values())
        filtered = [
            inc for inc in incidents
            if self._passes_disposition_filter(inc, allowed_dispositions)
            and self._passes_sub_disposition_filter(inc, allowed_sub_dispositions)
        ]
        return phantom.APP_SUCCESS, filtered

    # ------------------------------------------------------------------
    # MIME body helpers (shared by the on-demand action and on_poll)
    # ------------------------------------------------------------------

    def _fetch_incident_events(self, action_result, incident_id):
        """Fetch the full incident (expand_events=true) and return its events list.

        Returns:
            tuple: (status, events) — RetVal pattern; on failure the reason
            is already set on action_result.
        """
        url = "{}{}".format(self._base_url, INCIDENT_DETAIL_PATH.format(incident_id))
        ret_val, incident = self._make_rest_call(
            "GET", url, action_result, params={"expand_events": "true"}
        )
        if phantom.is_fail(ret_val):
            return ret_val, []
        if not isinstance(incident, dict):
            return action_result.set_status(
                phantom.APP_ERROR,
                "Unexpected incident {} response: expected a JSON object".format(incident_id),
            ), []
        return phantom.APP_SUCCESS, incident.get("events", []) or []

    def _download_mime(self, event_id):
        """Download the raw MIME (.eml) of one event (alert).

        Returns:
            tuple: (status, content, error_message) — RetVal pattern;
            content is the message bytes, None on failure.
        """
        path = ALERT_ORIGINAL_MSG_PATH.format(event_id)
        url = "{}{}".format(self._base_url, path)
        try:
            # The session's JSON Accept/Content-Type would ask for the wrong
            # representation; None drops the session value for this call.
            response = self._session.request(
                "GET", url, timeout=self._timeout, verify=self._verify,
                headers={"Accept": "message/rfc822", "Content-Type": None},
            )
        except requests.exceptions.SSLError:
            return phantom.APP_ERROR, None, ERR_SSL
        except requests.exceptions.ConnectionError:
            return phantom.APP_ERROR, None, ERR_CONNECTION.format(self._base_url)
        except requests.exceptions.Timeout:
            return phantom.APP_ERROR, None, ERR_TIMEOUT.format(self._timeout)
        except Exception as e:
            return phantom.APP_ERROR, None, "API Error: Unexpected error — {}".format(str(e))

        status_code = response.status_code
        content_type = response.headers.get("Content-Type", "")
        snippet = " ".join(response.text[:150].split()) if response.content else "(empty body)"

        if status_code == 404:
            return phantom.APP_ERROR, None, "{} [GET {}: {}]".format(
                ERR_EVENT_NOT_FOUND.format(event_id), path, snippet)
        if status_code in (401, 403):
            return phantom.APP_ERROR, None, ERR_AUTH
        if status_code != 200:
            return phantom.APP_ERROR, None, "API Error: HTTP {} [GET {}: {}]".format(
                status_code, path, snippet)
        # A 200 that is a web page or a JSON body is not a message -- vaulting
        # it as .eml would hand PB3 a fake email and report success.
        if not response.content or "html" in content_type or "json" in content_type:
            return phantom.APP_ERROR, None, (
                "Unexpected response for event {}: HTTP 200, Content-Type {!r}, "
                "expected message/rfc822 [GET {}: {}]".format(
                    event_id, content_type, path, snippet))

        return phantom.APP_SUCCESS, response.content, None

    def _vault_mime(self, incident_id, event_id, container_id, content):
        """Store one downloaded message in the container's Vault.

        Returns:
            tuple: (status, vault_id, file_name, error_message) — RetVal
            pattern; vault_id/file_name are None on failure.
        """
        file_name = "trap-{}-{}.eml".format(incident_id, event_id)
        try:
            vault_result = Vault.create_attachment(
                file_contents=content,
                container_id=container_id,
                file_name=file_name,
            )
        except Exception as e:
            return phantom.APP_ERROR, None, None, "Vault error: {}".format(str(e))

        if not vault_result.get("succeeded"):
            return phantom.APP_ERROR, None, None, "Vault error: {}".format(vault_result.get("message"))

        return phantom.APP_SUCCESS, vault_result.get("vault_id"), file_name, None

    # ------------------------------------------------------------------
    # Action: test connectivity
    # ------------------------------------------------------------------

    def _handle_test_connectivity(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        self.save_progress("Testing connectivity to Proofpoint TRAP")

        now = datetime.now(timezone.utc)
        one_hour_ago = (now - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ")

        url = "{}{}".format(self._base_url, INCIDENTS_PATH)
        params = {
            "state": "new",
            "created_after": one_hour_ago,
            "expand_events": "false",
        }

        ret_val, data = self._make_rest_call("GET", url, action_result, params=params)
        if phantom.is_fail(ret_val):
            self.save_progress("Connectivity test failed")
            return action_result.get_status()

        count = len(data) if isinstance(data, list) else 0
        self.save_progress(
            "Connectivity test passed — {} incidents found in last hour".format(count)
        )
        return action_result.set_status(phantom.APP_SUCCESS, "Connectivity test passed")

    # ------------------------------------------------------------------
    # Action: on poll
    # ------------------------------------------------------------------

    def _handle_on_poll(self, param):
        config = self.get_config()
        poll_state = config.get(POLL_STATE_KEY, DEFAULT_POLL_STATE)
        poll_hours = config.get(POLL_HOURS_KEY, DEFAULT_POLL_HOURS)
        disposition_csv = config.get(ABUSE_DISPOSITION_KEY, DEFAULT_ABUSE_DISPOSITION)
        allowed_dispositions = set(
            d.strip() for d in disposition_csv.split(",") if d.strip()
        )
        sub_disposition_csv = config.get(SUB_DISPOSITION_KEY, DEFAULT_SUB_DISPOSITION)
        allowed_sub_dispositions = set(
            d.strip() for d in sub_disposition_csv.split(",") if d.strip()
        )

        # Determine time window (Poll Now ignores checkpoint)
        now = datetime.now(timezone.utc)
        if self.is_poll_now():
            max_containers = param.get("container_count", 5)
            window_start = now - timedelta(hours=poll_hours)
        else:
            max_containers = 0  # no limit for scheduled polls
            last_poll = self._state.get("last_poll_time")
            if last_poll:
                window_start = datetime.strptime(
                    last_poll, "%Y-%m-%dT%H:%M:%SZ"
                ).replace(tzinfo=timezone.utc) - timedelta(minutes=POLL_OVERLAP_MINUTES)
            else:
                window_start = now - timedelta(hours=poll_hours)

        self.save_progress(
            "Polling TRAP — state={}, disposition={}, sub_disposition={}, since={}".format(
                poll_state, disposition_csv, sub_disposition_csv or "(any)",
                window_start.strftime("%Y-%m-%dT%H:%M:%SZ")
            )
        )

        # Fetch incidents in <=30-day chunks, filtered by disposition/sub disposition
        ret_val, filtered = self._fetch_and_filter_incidents(
            None, poll_state, window_start, now,
            allowed_dispositions, allowed_sub_dispositions,
        )
        if phantom.is_fail(ret_val):
            return self.get_status()

        # Apply container limit for Poll Now
        if max_containers:
            filtered = filtered[:max_containers]

        self.save_progress(
            "{} incidents to ingest{}".format(
                len(filtered),
                " (Poll Now, limit {})".format(max_containers) if self.is_poll_now() else ""
            )
        )

        # Get container label from ingest config
        container_label = config.get("ingest", {}).get("container_label")
        severity = config.get(SEVERITY_KEY, DEFAULT_SEVERITY)
        sensitivity = config.get(SENSITIVITY_KEY, DEFAULT_SENSITIVITY)

        recheck_days = self._recheck_days(config)

        # Create containers
        created = 0
        failed = []
        for incident in filtered:
            status, container_id = self._ingest_incident(incident, container_label, severity, sensitivity)
            if status == "created":
                created += 1
            elif status == "duplicate":
                self.debug_print("Duplicate container skipped for incident {}".format(incident.get("id", "")))
            else:
                failed.append(str(incident.get("id", "")))
            # A case missing its Event Info is tracked too: its next change
            # adds an Event Info Update, which starts the orchestrator.
            if recheck_days and status in ("created", "duplicate", "artifact_failed"):
                self._track_incident(incident, container_id, now, replace=(status != "duplicate"))

        # Changes to an already-ingested incident: scheduled polls only, like
        # the checkpoint. A failed recheck fails the poll but keeps what was ingested.
        recheck_error = None
        if recheck_days and not self.is_poll_now():
            recheck_error = self._recheck_tracked_incidents(now, recheck_days, window_start)

        # Update poll checkpoint (skip on Poll Now — manual polls don't advance cursor)
        if not self.is_poll_now():
            self._state["last_poll_time"] = now.strftime("%Y-%m-%dT%H:%M:%SZ")

        # The checkpoint has moved past a failed incident: only the failed poll
        # (and the progress lines above) report it.
        errors = []
        if failed:
            errors.append("ingest failed for incident(s) {}".format(", ".join(failed)))
        if recheck_error:
            errors.append("recheck failed: {}".format(recheck_error))
        if errors:
            return self.set_status(
                phantom.APP_ERROR,
                "{} containers created; {}".format(created, "; ".join(errors)),
            )
        self.save_progress(
            "on_poll complete — {} containers created".format(created)
        )
        return self.set_status(phantom.APP_SUCCESS)

    # ------------------------------------------------------------------
    # on_poll recheck: changes to ingested incidents
    # ------------------------------------------------------------------

    def _recheck_days(self, config):
        """recheck_days from the asset; an invalid value falls back to the default."""
        value = config.get(RECHECK_DAYS_KEY, DEFAULT_RECHECK_DAYS)
        try:
            if not float(value).is_integer() or int(value) < 0:
                raise ValueError()
            return int(value)
        except (TypeError, ValueError):
            self.save_progress("Invalid recheck_days {!r}: using {}".format(value, DEFAULT_RECHECK_DAYS))
            return DEFAULT_RECHECK_DAYS

    def _incident_signature(self, incident):
        """Hash of the incident's state and Event Info fields: a new alert
        changes eventIds, a TRAP edit the other fields."""
        payload = json.dumps(
            {"state": incident.get("state", ""), "event_info": self._build_event_info_cef(incident)},
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _track_incident(self, incident, container_id, now, replace):
        """Record the case of an ingested incident and its signature as
        ingested. replace=False keeps an existing entry, so a duplicate hit
        does not hide a change not yet rechecked."""
        tracked = self._state.setdefault(RECHECK_STATE_KEY, {})
        inc_id = str(incident.get("id", ""))
        if not inc_id or not container_id or (inc_id in tracked and not replace):
            return
        tracked[inc_id] = {
            "container_id": container_id,
            "created_at": incident.get("created_at", ""),
            "signature": self._incident_signature(incident),
            "touched": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    def _recheck_tracked_incidents(self, now, recheck_days, closed_since):
        """Add an Event Info Update (run_automation, which re-runs the
        orchestrator) to each tracked case whose incident changed in TRAP.
        Lists new and open incidents created in the last recheck_days, and
        incidents closed since the last successful recheck; a closed incident
        gets its last update and is no longer tracked.

        Returns:
            str: the error message when TRAP could not be listed, else None.
            Tracked state and the closed window are then left unchanged.
        """
        fmt = "%Y-%m-%dT%H:%M:%SZ"
        tracked = self._state.setdefault(RECHECK_STATE_KEY, {})
        tick = now.strftime(fmt)
        if not tracked:
            self._state[RECHECK_CLOSED_TIME_KEY] = tick
            return None
        window_start = now - timedelta(days=recheck_days)
        last_closed = self._state.get(RECHECK_CLOSED_TIME_KEY)
        if last_closed:
            closed_since = datetime.strptime(last_closed, fmt).replace(
                tzinfo=timezone.utc) - timedelta(minutes=POLL_OVERLAP_MINUTES)
        closed_since = max(closed_since, window_start)

        listed = {}
        for state, date_field, since in (("new", "created", window_start),
                                         ("open", "created", window_start),
                                         (None, "closed", closed_since)):
            ret_val, incidents = self._fetch_and_filter_incidents(
                None, state, since, now, set(), set(), date_field=date_field,
            )
            if phantom.is_fail(ret_val):
                return "listing {} incidents: {}".format(state or "closed", self.get_status_message())
            for incident in incidents:
                listed[str(incident.get("id", ""))] = incident

        settle_cutoff = (now - timedelta(minutes=RECHECK_SETTLE_MINUTES)).strftime(fmt)
        window_start_str = window_start.strftime(fmt)
        updated = 0
        for inc_id, entry in list(tracked.items()):
            incident = listed.get(inc_id)
            if incident is None:
                if entry.get("created_at", "") < window_start_str:
                    del tracked[inc_id]
                continue
            closed = incident.get("state") == "closed"
            signature = self._incident_signature(incident)
            if signature == entry["signature"]:
                if closed:
                    del tracked[inc_id]
                continue
            if entry.get("touched", "") > settle_cutoff:
                continue

            try:
                ret_val, case, status_code = self.get_container_info(entry["container_id"])
            except Exception as e:  # a non-JSON error body raises inside get_container_info
                ret_val, case, status_code = phantom.APP_ERROR, str(e), 0
            if phantom.is_fail(ret_val):
                if status_code == 404:
                    del tracked[inc_id]
                else:
                    self.save_progress("Recheck: case {} of incident {} unreadable, retried next poll -- {}".format(
                        entry["container_id"], inc_id, case))
                continue
            # A case closed in SOAR runs no automation; an update would only raise its severity.
            if str(case.get("status") or "").lower() != "closed":
                cef = self._build_event_info_cef(incident)
                cef["message"] = "TRAP incident {} changed since last enrichment".format(inc_id)
                # The tick makes each update new content, so a change back to an
                # earlier state still re-runs the orchestrator.
                cef["recheckTime"] = tick
                ret_val, message, _artifact_id = self.save_artifact({
                    "name": "Event Info Update",
                    "container_id": entry["container_id"],
                    "source_data_identifier": "trap-{}-recheck-{}".format(inc_id, tick),
                    "label": "event",
                    # low never raises the case's severity; triage owns it.
                    "severity": "low",
                    "cef": cef,
                    "cef_types": {"incidentId": ["proofpoint trap incident id"]},
                    "run_automation": True,
                })
                if phantom.is_fail(ret_val):
                    self.save_progress("Recheck: Event Info Update on case {} failed, retried next poll -- {}".format(
                        entry["container_id"], message))
                    continue
                updated += 1
            if closed:
                del tracked[inc_id]
            else:
                entry["signature"] = signature
                entry["touched"] = tick

        # A closed incident still tracked (settling, or its update failed) must
        # be listed again: the closed window moves on only once none is left.
        if not any(listed.get(inc_id, {}).get("state") == "closed" for inc_id in tracked):
            self._state[RECHECK_CLOSED_TIME_KEY] = tick
        self.save_progress("Recheck: {} case(s) tracked, {} Event Info Update(s) added".format(len(tracked), updated))
        return None

    def _ingest_incident(self, incident, container_label, severity, sensitivity):
        """Create a container + artifacts for one incident.

        Returns:
            tuple: (status, container_id). status is "created", "duplicate",
            "artifact_failed" (case created, Event Info not saved) or
            "failed" (no case). container_id is set for all but "failed"
            (save_container returns the existing container's id on a
            duplicate hit).
        """
        inc_id = incident.get("id", "")
        # Real incidents often carry an empty summary, which .get()'s default
        # does not replace.
        summary = incident.get("summary") or incident.get("description") or "No summary"

        container = {
            "name": "TRAP-{}: {}".format(inc_id, summary),
            "description": incident.get("description", ""),
            "source_data_identifier": str(inc_id),
            # Initial value only; proofpoint_trap_triage sets the real one.
            "severity": severity,
            "sensitivity": sensitivity,
            "status": "new",
            "start_time": incident.get("created_at", ""),
            "data": incident,
        }
        if container_label:
            container["label"] = container_label

        ret_val, msg, container_id = self.save_container(container)

        if phantom.is_fail(ret_val):
            self.save_progress("Incident {}: case not created -- {}".format(inc_id, msg))
            return "failed", None

        if "duplicate container found" in msg.lower():
            return "duplicate", container_id

        # Create artifacts — run_automation set on last artifact only
        artifacts = self._build_on_poll_artifacts(incident, container_id)

        if artifacts:
            artifacts[-1]["run_automation"] = True
            ret_val, msg, _artifact_ids = self.save_artifacts(artifacts)
            # Without its Event Info the case never starts the orchestrator.
            if phantom.is_fail(ret_val):
                self.save_progress("Incident {}: Event Info not saved on case {} -- {}".format(
                    inc_id, container_id, msg))
                return "artifact_failed", container_id

        return "created", container_id

    def _build_event_info_cef(self, incident):
        """CEF fields of the "Event Info" artifact, and of the "Event Info
        Update" the recheck adds when they change."""
        inc_id = incident.get("id", "")
        disposition = self._get_disposition(incident)
        sub_disposition = self._get_field_value(incident, "Sub Disposition")
        classification = self._get_field_value(incident, "Classification")
        trap_severity = self._get_field_value(incident, "Severity")
        score = incident.get("score", 0)
        # Same empty-summary fallback as the container name (see _handle_on_poll)
        message = incident.get("summary") or incident.get("description") or ""
        # event_ids is present even in the list response (expand_events=false).
        event_ids = ",".join(str(x) for x in (incident.get("event_ids") or []))

        return {
            "abuseDisposition": disposition,
            "classification": classification,
            "subDisposition": sub_disposition,
            "threatScore": score,
            "incidentId": str(inc_id),
            "eventIds": event_ids,
            "trapSeverity": trap_severity,
            "message": message,
        }

    def _build_on_poll_artifacts(self, incident, container_id):
        inc_id = incident.get("id", "")

        return [{
            "name": "Event Info",
            "container_id": container_id,
            "source_data_identifier": "trap-{}-info".format(inc_id),
            "label": "event",
            "cef": self._build_event_info_cef(incident),
            "cef_types": {"incidentId": ["proofpoint trap incident id"]},
        }]

    # ------------------------------------------------------------------
    # Action: list incidents
    # ------------------------------------------------------------------

    def _handle_list_incidents(self, param):
        """List/search TRAP incidents by state, time window, and Abuse/Sub
        Disposition — same filtering on_poll uses for ingestion, exposed as
        an on-demand action instead of the fixed ingest config."""
        action_result = self.add_action_result(ActionResult(dict(param)))

        state = param.get("state", DEFAULT_POLL_STATE)

        disposition_csv = param.get("abuse_disposition", "")
        allowed_dispositions = set(
            d.strip() for d in disposition_csv.split(",") if d.strip()
        )
        sub_disposition_csv = param.get("sub_disposition", "")
        allowed_sub_dispositions = set(
            d.strip() for d in sub_disposition_csv.split(",") if d.strip()
        )
        expand_events = "true" if param.get("expand_events", False) else "false"

        now = datetime.now(timezone.utc)
        # Validated like every other numeric parameter here: a VPE literal
        # arrives as a string, which timedelta() rejects outright.
        window_hours = self._validate_integer(
            action_result, param.get("hours_back", DEFAULT_POLL_HOURS), "hours_back"
        )
        if window_hours is None:
            return action_result.get_status()
        window_start = now - timedelta(hours=window_hours)

        self.save_progress(
            "Listing TRAP incidents — state={}, disposition={}, sub_disposition={}, since={}".format(
                state, disposition_csv or "(any)", sub_disposition_csv or "(any)",
                window_start.strftime("%Y-%m-%dT%H:%M:%SZ")
            )
        )

        ret_val, filtered = self._fetch_and_filter_incidents(
            action_result, state, window_start, now,
            allowed_dispositions, allowed_sub_dispositions,
            expand_events=expand_events,
        )
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        max_results = param.get("max_results", 0)
        if max_results:
            filtered = filtered[:max_results]

        for incident in filtered:
            action_result.add_data(incident)

        action_result.update_summary({"total_incidents": len(filtered)})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "{} incident(s) found".format(len(filtered)),
        )

    # ------------------------------------------------------------------
    # Action: get incident
    # ------------------------------------------------------------------

    def _incident_ui_url(self, incident_id):
        """The incident's page in the TRAP web UI: /incidents/<id> on the host
        of base_url (the web UI and the API share it)."""
        parsed = urlparse(self._base_url or "")
        if not parsed.scheme or not parsed.netloc:
            return ""
        return "{}://{}/incidents/{}".format(parsed.scheme, parsed.netloc, incident_id)

    def _handle_get_incident(self, param):
        """Retrieve one or more TRAP incidents. Accepts str or list."""
        action_result = self.add_action_result(ActionResult(dict(param)))

        # Accept a single value, a list, or a comma-joined string. SOAR sends
        # the last form when the parameter is bound to a wildcard datapath
        # ("artifact:*.cef.incidentId"): every artifact's value joined with
        # ", ", the literal "None" for artifacts without the field.
        raw_input = param.get("incident_id")
        if isinstance(raw_input, list):
            raw_ids = [x for x in raw_input if x not in (None, "")]
        elif isinstance(raw_input, str) and "," in raw_input:
            raw_ids = [
                part.strip() for part in raw_input.split(",")
                if part.strip() and part.strip().lower() != "none"
            ]
            if not raw_ids:
                return action_result.set_status(
                    phantom.APP_ERROR,
                    "'incident_id' resolved to no usable value(s): {!r}".format(raw_input)
                )
        elif raw_input not in (None, ""):
            raw_ids = [raw_input]
        else:
            return action_result.set_status(
                phantom.APP_ERROR, "Required parameter 'incident_id' is missing"
            )

        # Default True preserves prior hardcoded behavior for existing callers
        # (e.g. proofpoint_trap_detail never sets this param).
        expand_events = "true" if param.get("expand_events", True) else "false"

        succeeded, failed = 0, 0
        last_event_count = 0
        errors = []

        for raw_id in raw_ids:
            incident_id = self._validate_integer(action_result, raw_id, "incident_id")
            if incident_id is None:
                failed += 1
                errors.append("invalid id '{}'".format(raw_id))
                continue

            url = "{}{}".format(self._base_url, INCIDENT_DETAIL_PATH.format(incident_id))
            ret_val, incident = self._make_rest_call(
                "GET", url, action_result, params={"expand_events": expand_events}
            )
            if phantom.is_fail(ret_val):
                failed += 1
                errors.append("id={}: {}".format(incident_id, action_result.get_message()))
                continue

            incident["incident_url"] = self._incident_ui_url(incident_id)
            action_result.add_data(incident)
            last_event_count = incident.get("event_count", 0)
            succeeded += 1

        action_result.update_summary({
            "succeeded": succeeded,
            "failed": failed,
            "total": len(raw_ids),
            "event_count": last_event_count,
        })

        if succeeded == 0:
            return action_result.set_status(
                phantom.APP_ERROR,
                "All {} incident lookups failed: {}".format(
                    failed, "; ".join(errors)[:500]
                )
            )
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "{}/{} incidents retrieved".format(succeeded, len(raw_ids))
        )

    # ------------------------------------------------------------------
    # Action: close incident
    # ------------------------------------------------------------------

    def _handle_close_incident(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        summary = param.get("summary", "")
        detail = param.get("detail", "")

        url = "{}{}".format(self._base_url, INCIDENT_CLOSE_PATH.format(incident_id))
        body = {"summary": summary, "detail": detail}

        ret_val, _ = self._make_rest_call("POST", url, action_result, json=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"success": True})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Incident {} closed".format(incident_id),
        )

    # ------------------------------------------------------------------
    # Action: add comment
    # ------------------------------------------------------------------

    def _handle_add_comment(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        summary = param.get("summary", "")
        detail = param.get("detail", "")

        url = "{}{}".format(self._base_url, INCIDENT_COMMENT_PATH.format(incident_id))
        # The API doc marks detail optional, but the appliance answers a body
        # without it with HTTP 500 "java.lang.NullPointerException: Null detail".
        body = {"summary": summary, "detail": detail}

        ret_val, _ = self._make_rest_call("POST", url, action_result, json=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"success": True})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Comment added to incident {}".format(incident_id),
        )

    # ------------------------------------------------------------------
    # Incident-update actions: POST /api/incidents/{id}/... endpoints
    # (proofpoint_trap_api_reference.md). /api/v1/alerts is GET-only.
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Action: add user to incident
    # ------------------------------------------------------------------

    def _handle_add_user_to_incident(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        targets = [t.strip() for t in param.get("targets", "").split(",") if t.strip()]
        attackers = [a.strip() for a in param.get("attackers", "").split(",") if a.strip()]
        if not targets and not attackers:
            return action_result.set_status(
                phantom.APP_ERROR, "At least one of 'targets' or 'attackers' is required"
            )

        url = "{}{}".format(self._base_url, INCIDENT_USERS_PATH.format(incident_id))
        body = {"targets": targets, "attackers": attackers}

        ret_val, _ = self._make_rest_call("POST", url, action_result, json=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"success": True})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Users added to incident {} (targets={}, attackers={})".format(
                incident_id, targets, attackers
            ),
        )

    # ------------------------------------------------------------------
    # Action: update incident description
    # ------------------------------------------------------------------

    def _handle_update_incident_description(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        description = param.get("description", "")
        overwrite = param.get("overwrite", False)

        url = "{}{}".format(self._base_url, INCIDENT_DESCRIPTION_PATH.format(incident_id))
        body = {"description": description, "overwrite": overwrite}

        ret_val, _ = self._make_rest_call("POST", url, action_result, json=body)
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"success": True})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Description {} on incident {}".format(
                "overwritten" if overwrite else "appended", incident_id
            ),
        )

    # ------------------------------------------------------------------
    # Action: update team and assignee
    # ------------------------------------------------------------------

    def _handle_update_incident_assignee(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        assignee = param.get("assignee", "")
        team = param.get("team", "")

        # The appliance rejects a request with only one of the two; fail fast
        # with the message it would return.
        if not assignee or not team:
            return action_result.set_status(
                phantom.APP_ERROR,
                "Both team and assignee are required. Team: {}, assignee: {}".format(
                    team or "null", assignee or "null"
                ),
            )

        body = {"assignee": assignee, "team": team}

        url = "{}{}".format(self._base_url, INCIDENT_TEAM_ASSIGNEE_PATH.format(incident_id))

        ret_val, _ = self._make_rest_call("POST", url, action_result, json=body)
        if phantom.is_fail(ret_val):
            # A 404 "previous team and assignee are same" means nothing to
            # change: success. Any other failure (unknown assignee, the
            # appliance's ConstraintViolationException, see README.md) passes
            # through unchanged.
            raw_msg = action_result.get_message() or ""
            if "previous team and assignee are same" not in raw_msg.lower():
                return action_result.get_status()
            action_result.add_data({"success": True, "no_op": True})
            action_result.update_summary({"incident_id": incident_id})
            return action_result.set_status(
                phantom.APP_SUCCESS,
                "Incident {} already had this team/assignee — no change made".format(incident_id),
            )

        action_result.add_data({"success": True, "no_op": False})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Team/assignee updated on incident {}".format(incident_id),
        )

    # ------------------------------------------------------------------
    # Action: set incident field value
    # ------------------------------------------------------------------

    def _handle_set_incident_field(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()
        field = param.get("field", "")
        value = param.get("value", "")
        if not field:
            return action_result.set_status(phantom.APP_ERROR, "'field' is required")

        url = "{}{}".format(self._base_url, INCIDENT_FIELDS_PATH.format(incident_id))
        body = {"fields": {field: value}}

        ret_val, _ = self._make_rest_call(
            "POST", url, action_result, params={"allow_data_override": "true"}, json=body
        )
        if phantom.is_fail(ret_val):
            return action_result.get_status()

        action_result.add_data({"success": True})
        action_result.update_summary({"incident_id": incident_id})
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "Field '{}' set to '{}' on incident {}".format(field, value, incident_id),
        )

    # ------------------------------------------------------------------
    # Action: download mime body
    # ------------------------------------------------------------------

    def _handle_download_mime_body(self, param):
        """Download the raw MIME body for one event, or all events on an
        incident when event_id is omitted, and store each in the container's
        Vault when the action runs in one."""
        action_result = self.add_action_result(ActionResult(dict(param)))

        incident_id = self._validate_integer(action_result, param.get("incident_id"), "incident_id")
        if incident_id is None:
            return action_result.get_status()

        container_id = self.get_container_id()
        # Run from the asset's action panel (App Debugger) there is no
        # container, and so no Vault: download and check each message, but
        # skip storing it rather than fail every event.
        store = bool(container_id)
        if not store:
            self.save_progress(
                "Run outside a container: messages are downloaded and checked, not stored in the Vault")
        raw_event_id = param.get("event_id")

        if raw_event_id not in (None, ""):
            event_ids = [raw_event_id]
        else:
            ret_val, events = self._fetch_incident_events(action_result, incident_id)
            if phantom.is_fail(ret_val):
                message = "Could not list the events of incident {}: {}".format(
                    incident_id, action_result.get_message())
                self.save_progress(message)
                return action_result.set_status(phantom.APP_ERROR, message)
            event_ids = [e.get("id") for e in events if e.get("id")]
            if not event_ids:
                return action_result.set_status(
                    phantom.APP_ERROR,
                    "Incident {} has no events to fetch MIME for".format(incident_id),
                )

        succeeded, failed = 0, 0
        errors = []

        for event_id in event_ids:
            vault_id, file_name = None, None
            ret_val, content, err = self._download_mime(event_id)
            if not phantom.is_fail(ret_val) and store:
                ret_val, vault_id, file_name, err = self._vault_mime(
                    incident_id, event_id, container_id, content
                )
            if phantom.is_fail(ret_val):
                failed += 1
                errors.append((event_id, err))
                # save_progress is what reaches an operator with no shell;
                # the action message below quotes only the first error.
                self.save_progress("MIME download failed -- event {}: {}".format(event_id, err))
                continue

            action_result.add_data({
                "event_id": event_id,
                "vault_id": vault_id,
                "file_name": file_name,
                "size": len(content),
                "subject": _mime_subject(content),
            })
            succeeded += 1

        action_result.update_summary({
            "succeeded": succeeded,
            "failed": failed,
            "total": len(event_ids),
        })

        if succeeded == 0:
            return action_result.set_status(
                phantom.APP_ERROR,
                "All {} MIME downloads failed -- event {}: {}{}".format(
                    failed, errors[0][0], errors[0][1],
                    " (also failed: events {})".format(_event_list(errors[1:])) if failed > 1 else ""),
            )
        return action_result.set_status(
            phantom.APP_SUCCESS,
            "{}/{} MIME bodies downloaded{}{}".format(
                succeeded, len(event_ids),
                " (failed: events {})".format(_event_list(errors)) if errors else "",
                "" if store else " -- not stored: run outside a container, so there is no Vault"),
        )


def _event_list(errors):
    return ", ".join(str(event_id) for event_id, _ in errors)


def _mime_subject(content):
    """Decoded Subject header, so a run shows WHICH message came back."""
    try:
        headers = BytesHeaderParser(policy=email.policy.default).parsebytes(content)
        return str(headers.get("Subject") or "")[:200]
    except Exception:
        return ""


def main():
    import argparse

    argparser = argparse.ArgumentParser()
    argparser.add_argument("input_test_json", help="Input Test JSON file")
    args = argparser.parse_args()

    with open(args.input_test_json) as f:
        in_json = f.read()
        in_json = json.loads(in_json)

    connector = ProofpointTrapConnector()
    connector.print_progress_message = True
    ret_val = connector._handle_action(json.dumps(in_json), None)
    print(json.dumps(json.loads(ret_val), indent=4))

    sys.exit(0)


if __name__ == "__main__":
    main()
